const leaders = {
  autumn: {
    name: "Autumn Peltier",
    section: "#autumn",
    short: "You matched with Autumn Peltier because you care about water, land, and future generations."
  },
  murray: {
    name: "Murray Sinclair",
    section: "#murray",
    short: "You matched with Murray Sinclair because you care about truth, justice, and education."
  },
  cindy: {
    name: "Cindy Blackstock",
    section: "#cindy",
    short: "You matched with Cindy Blackstock because you care about fairness, children, and equal opportunity."
  },
  tanya: {
    name: "Tanya Tagaq",
    section: "#tanya",
    short: "You matched with Tanya Tagaq because you care about art, culture, and using creativity to challenge people."
  },
  wab: {
    name: "Wab Kinew",
    section: "#wab",
    short: "You matched with Wab Kinew because you care about leadership, voice, and public change."
  },
  tomson: {
    name: "Tomson Highway",
    section: "#tomson",
    short: "You matched with Tomson Highway because you care about storytelling, language, and culture."
  }
};

const quizForm = document.getElementById("quizForm");
const resultSection = document.getElementById("result");
const resultContent = document.getElementById("resultContent");
const retakeButton = document.getElementById("retakeButton");

quizForm.addEventListener("submit", function(event) {
  event.preventDefault();

  const formData = new FormData(quizForm);
  const scores = {
    autumn: 0,
    murray: 0,
    cindy: 0,
    tanya: 0,
    wab: 0,
    tomson: 0
  };

  for (const value of formData.values()) {
    scores[value]++;
  }

  let topLeader = "autumn";

  for (const leader in scores) {
    if (scores[leader] > scores[topLeader]) {
      topLeader = leader;
    }
  }

  showResult(topLeader);
});

function showResult(leaderKey) {
  const leader = leaders[leaderKey];

  resultContent.innerHTML = `
    <div class="result-box">
      <h3>${leader.name}</h3>
      <p>${leader.short}</p>
      <a class="button" href="${leader.section}">Open ${leader.name}'s Profile</a>
    </div>
  `;

  resultSection.classList.remove("hidden");
  resultSection.scrollIntoView({ behavior: "smooth" });
}

retakeButton.addEventListener("click", function() {
  quizForm.reset();
  resultSection.classList.add("hidden");
  document.getElementById("quiz").scrollIntoView({ behavior: "smooth" });
});
