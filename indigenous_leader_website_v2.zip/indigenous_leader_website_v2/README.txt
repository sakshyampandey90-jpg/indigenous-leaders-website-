HOW TO EDIT THIS WEBSITE

index.html = all the writing and leader sections.
style.css = colours, sidebar, layout, spacing.
script.js = quiz matching and result message.

HOW TO OPEN:
Double click index.html.

HOW TO CHANGE CINDY BLACKSTOCK INFO:
1. Open index.html.
2. Press Ctrl + F.
3. Search Cindy Blackstock.
4. Change the paragraph or bullet points.
5. Press Ctrl + S.
6. Refresh the website.

HOW TO CHANGE THE SIDEBAR:
Open index.html and edit the links inside <aside class="sidebar">.

HOW TO CHANGE QUIZ RESULTS:
Open script.js and edit the text inside leaders = { ... }.
